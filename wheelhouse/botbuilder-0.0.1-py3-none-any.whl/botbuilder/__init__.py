__author__ = 'sandeep'
__title__ = 'BotBuilder Python Client'
__version__ = '0.0.1'

# Version synonym
VERSION = __version__